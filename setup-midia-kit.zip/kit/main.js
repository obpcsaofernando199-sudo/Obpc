/* Estúdio de Mídia — OBPC: janela do aplicativo para Windows.
   Abre a versão publicada no GitHub Pages, então toda atualização do site
   chega sozinha para todos os componentes (sem reinstalar). */
const { app, BrowserWindow, session, shell, Menu } = require('electron');
const path = require('path');

// ⚠ TROQUE pelo endereço real da sua página (GitHub Pages):
const APP_URL = 'https://serfico21-arch.github.io/Pessoal/midia-estudio.html';
const ORIGIN = new URL(APP_URL).origin;

if (!app.requestSingleInstanceLock()) { app.quit(); }
let win;
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

function liberado(url) { try { return new URL(url).origin === ORIGIN; } catch (e) { return false; } }

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  const ses = session.defaultSession;
  // microfone, câmera, tela cheia e área de transferência: só para o próprio site do estúdio
  const ok = ['media', 'audioCapture', 'videoCapture', 'fullscreen', 'clipboard-sanitized-write', 'notifications'];
  ses.setPermissionRequestHandler((wc, perm, cb, details) => cb(ok.includes(perm) && liberado(details.requestingUrl || wc.getURL())));
  ses.setPermissionCheckHandler((wc, perm, origin) => ok.includes(perm) && liberado(origin));

  win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 380, minHeight: 600,
    title: 'Estúdio de Mídia — OBPC', autoHideMenuBar: true, backgroundColor: '#0b0f17',
    webPreferences: { contextIsolation: true, sandbox: true, nodeIntegration: false }
  });
  win.loadURL(APP_URL);
  // sem internet / site fora do ar → tela amigável com botão "Tentar de novo"
  win.webContents.on('did-fail-load', (e, code, desc, url, isMain) => {
    if (isMain && code !== -3) win.loadFile(path.join(__dirname, 'offline.html'), { query: { u: APP_URL } });
  });
  // links externos abrem no navegador; links do próprio estúdio abrem na janela
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (liberado(url)) return { action: 'allow' };
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!liberado(url) && !url.startsWith('file:')) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); }
  });
});
app.on('window-all-closed', () => app.quit());
